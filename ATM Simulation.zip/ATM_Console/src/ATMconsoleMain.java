import GUI.login;

public class ATMconsoleMain {
    public static void main(String[] args) {
        login user=new login();
        user.setVisible(true);
    }
}
