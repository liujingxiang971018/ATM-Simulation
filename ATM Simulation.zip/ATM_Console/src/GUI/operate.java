/*
 * Created by JFormDesigner on Wed Nov 20 16:37:44 CST 2019
 */

package GUI;

import sql.connection;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.GroupLayout;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.event.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/**
 * @author liujingxiang
 */
public class operate extends JFrame {

    public operate(String number) {
        initComponents();
        job_number.setText(number);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
                    date.setText(dateFormat.format(time));
                }
            }
        }).start();

        HashSet<String> filter_atmset=get_filter_atmset(number);
        get_clickedvalue(get_AtmTable(filter_atmset));


        system_switch_RadioButton.addActionListener(event -> system_switch_RadioButtonStateChanged(event, global_atm_switch, global_atm_state, global_value));
        amount_input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                amount_inputKeyPressed(e, global_value, global_atm_switch, global_avail_amount);
            }
        });
    }
    private HashSet<String> get_filter_atmset(String number) {
        //在ATM选择栏中添加菜单条目
        //第一步：先查询当前工号可以管理的区域
        HashSet<String> filter_atmset = new HashSet<>();
        connection c= new connection();
        Connection conn=c.CreateSqlConnection();
        String selectArea_sql = "SELECT * FROM atm.staff_info where staff_id=" + number;
        String selectAtm_sql = "select * from atm.atm_info";
        try {
            Statement statement = conn.createStatement();
            ResultSet staffset = statement.executeQuery(selectArea_sql);
            staffset.next();
            String work_area = staffset.getString("work_area");
            staffset.close();
            //第二步：获取管理的ATM机的编号
            ResultSet atmset = statement.executeQuery(selectAtm_sql);

            while (atmset.next()) {
                String atm_location = atmset.getString("atm_location");
                if (atm_location.contains(work_area)) {
                    filter_atmset.add(atmset.getString("atm_id"));
                }
            }
            atmset.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return filter_atmset;
    }
    private JTable get_AtmTable(HashSet<String> filter_atmset){
        System.out.println(filter_atmset);
        //第三步：创建菜单框，并添加事件
        Object[] obj=new Object[filter_atmset.size()];
        int count=0;
        for(String atm_id:filter_atmset){
            obj[count]=atm_id;
            count++;
        }
        //String[] columnNames={"ATM编号"};
        JTable table=new JTable();
        //单元格不能被编辑
        DefaultTableModel t=SetTableEditableOff();
        t.addColumn("ATM编号",obj);
        table.setModel(t);

        //数据居中对齐
        DefaultTableCellRenderer r=SetTableCenter();
        table.setDefaultRenderer(Object.class, r);

        scrollPane1.getViewport().add(table);
        return table;
    }

    static boolean global_atm_state;
    static boolean global_atm_switch;
    static Object global_value=null;
    static String global_avail_amount=null;

    private void get_clickedvalue(JTable table){

        //第四步：设置单元格触发事件,监听鼠标事件,在右端基本信息输出框中输出信息
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row=table.getSelectedRow();
                int col=table.getSelectedColumn();
                Object value=table.getValueAt(row,col);

                System.out.println("点击的编号:"+value);
                connection c= new connection();
                Connection conn=c.CreateSqlConnection();
                String selectatmInfo_sql="select * from atm.atm_info where atm_id="+value;
                String selecttransaction_sql="select * from atm.transaction_info where atm_id="+value;

                try {
                    Statement statement2 = conn.createStatement();
                    ResultSet atmInfo = statement2.executeQuery(selectatmInfo_sql);
                    atmInfo.next();

                    System.out.println(atmInfo.getString("atm_name"));
                    String bank_type = atmInfo.getString("bank_type");
                    String atm_location = atmInfo.getString("atm_location");
                    String atm_name = atmInfo.getString("atm_name");
                    String atm_networknumber = atmInfo.getString("atm_networknumber");
                    boolean atm_switch = atmInfo.getBoolean("switch_flag");
                    boolean atm_state = atmInfo.getBoolean("state_flag");
                    String avail_amount = atmInfo.getString("avail_amount");
                    System.out.println(atm_switch + " " + atm_state);

                    atmInfo.close();

                    basic_info_input.setText("bank_type：" + bank_type + "   networkIP：" + atm_networknumber + "\n\n");
                    basic_info_input.append("atm_location：" + atm_location + "   atm_name：" + atm_name + "\n");
                    system_switch_RadioButton.setSelected(atm_switch);
                    if (atm_state) {
                        use_state_input.setText("ON");
                    } else {
                        use_state_input.setText("OFF");
                    }
                    amount_input.setText(avail_amount);

                    global_value=value;
                    global_atm_switch=atm_switch;
                    global_atm_state=atm_state;
                    global_avail_amount=avail_amount;

                    //将交易日志信息输出到表格中，不可编辑
                    //....
                    ResultSet transactionInfo = statement2.executeQuery(selecttransaction_sql);
                    //设置不能单元格被编辑和居中
                    transactionInfo.last();
                    String[][] transaction = new String[9][transactionInfo.getRow()];

                    int count = 0;
                    transactionInfo.beforeFirst();
                    while (transactionInfo.next()) {
                        for (int i = 0; i < 9; i++) {
                            transaction[i][count] = transactionInfo.getString(i + 1);
                            //System.out.println(transactionInfo.getString(i + 1));
                        }
                        count++;
                    }
                    DefaultTableModel t = SetTableEditableOff();
                    t.addColumn("trans_id", transaction[0]);
                    t.addColumn("trans_date", transaction[1]);
                    t.addColumn("atm_id", transaction[2]);
                    t.addColumn("atm_loc", transaction[3]);
                    t.addColumn("trans_type", transaction[4]);
                    t.addColumn("src_card", transaction[5]);
                    t.addColumn("des_card", transaction[6]);
                    t.addColumn("trans_amount", transaction[7]);
                    t.addColumn("exc_amount", transaction[8]);

                    log_table.setModel(t);
                    //居中
                    DefaultTableCellRenderer r = SetTableCenter();
                    log_table.setDefaultRenderer(Object.class, r);

                    transactionInfo.close();
                    conn.close();
                } catch (SQLException ex) {
                    System.out.println("查询ATM机基本信息出现问题");
                    ex.printStackTrace();
                }

            }
        });
    }


    //table中单元格不能被编辑
    private DefaultTableModel SetTableEditableOff(){
        DefaultTableModel t=new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        return t;
    }
    //table中单元格居中
    private DefaultTableCellRenderer SetTableCenter(){
        DefaultTableCellRenderer r=new DefaultTableCellRenderer();
        r.setHorizontalAlignment(JLabel.CENTER);

        return r;
    }

    //exit按钮退出
    private void exitActionPerformed(ActionEvent e) {
        System.exit(0);
    }

    //radio单选框状态改变，向数据库中修改数据,需要先传入atm_id,修改之前需要判定ATM是否正在使用
    private void system_switch_RadioButtonStateChanged(ActionEvent e,Boolean atm_switch,Boolean atm_state,Object value) {
        if(value!=null) {
            if (atm_state == true) {
                JOptionPane.showMessageDialog(null, "ATM正在使用中，不能关闭，请稍后再试", "Warning", JOptionPane.WARNING_MESSAGE);
                system_switch_RadioButton.setSelected(atm_switch);
            } else {
                System.out.println("value=" + value);
                boolean state = system_switch_RadioButton.isSelected();
                System.out.println("当前状态：" + state);
                connection c = new connection();
                Connection conn = c.CreateSqlConnection();
                if (state == true) {
                    //sql修改语句
                    String update_sql = "update atm.atm_info set switch_flag=" + 1 + " where atm_id=" + value;
                    try {
                        Statement statement_update = conn.createStatement();
                        statement_update.executeUpdate(update_sql);
                        global_atm_switch=state;
                        System.out.println("ATM系统状态更新成功");
                        conn.close();
                    } catch (SQLException ex) {
                        System.out.println("ATM系统状态更新失败");
                        ex.printStackTrace();
                    }

                } else {
                    //sql修改语句
                    String update_sql = "update atm.atm_info set switch_flag=" + 0 + " where atm_id=" + value;
                    try {
                        Statement statement_update = conn.createStatement();
                        statement_update.executeUpdate(update_sql);
                        global_atm_switch=state;
                        System.out.println("ATM系统状态更新成功");
                        conn.close();
                    } catch (SQLException ex) {
                        System.out.println("ATM系统状态更新失败");
                        ex.printStackTrace();
                    }
                }
                //c.CloseSqlConnection(conn);
            }
        }
    }

    //输入atm余额框中按下enter键，则修改atm_info表中的值
    private void amount_inputKeyPressed(KeyEvent e, Object value, Boolean atm_switch, String avail_amount) {
        if(value!=null) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                System.out.println("执行修改ATM的可用金额操作");
                if (atm_switch == true) {
                    //ATM已打开，不能修改，弹出信息框
                    JOptionPane.showMessageDialog(null, "ATM已打开，不能修改，请稍后再试", "Warning", JOptionPane.WARNING_MESSAGE);
                    amount_input.setText(avail_amount);
                } else {
                    //ATM已关闭，开始修改
                    String dst_availAmount = amount_input.getText();
                    String update_sql = "update atm.atm_info set avail_amount =" + dst_availAmount + " where atm_id =" + value;
                    connection c = new connection();
                    Connection conn = c.CreateSqlConnection();
                    try {
                        Statement statement = conn.createStatement();
                        statement.executeUpdate(update_sql);
                        System.out.println("更新ATM余额成功");
                        conn.close();
                    } catch (SQLException ex) {
                        System.out.println("更新ATM余额失败");
                        ex.printStackTrace();
                    }
                }
            } else {
                //无效修改操作
            }
        }
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        job_number = new JTextField();
        select_panel = new JPanel();
        scrollPane1 = new JScrollPane();
        bar_panel = new JPanel();
        date = new JTextField();
        exit = new JButton();
        basicinfo_panel = new JPanel();
        scrollPane2 = new JScrollPane();
        basic_info_input = new JTextArea();
        system_panel = new JPanel();
        system_switch_RadioButton = new JRadioButton();
        system_switch_label = new JLabel();
        use_state_label = new JLabel();
        use_state_input = new JTextField();
        amount_label = new JLabel();
        amount_input = new JTextField();
        scrollPane3 = new JScrollPane();
        log_table = new JTable();

        //======== this ========
        setResizable(false);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setBackground(Color.white);
        setTitle("ATM Console");
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c\u63a7\u5236\u53f0");
            signal.setEditable(false);
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getSize() + 4f));
            signal.setBackground(new Color(187, 187, 187));

            //---- job_number ----
            job_number.setEditable(false);
            job_number.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addGap(158, 158, 158)
                        .addComponent(job_number, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(job_number, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            );
        }

        //======== select_panel ========
        {

            GroupLayout select_panelLayout = new GroupLayout(select_panel);
            select_panel.setLayout(select_panelLayout);
            select_panelLayout.setHorizontalGroup(
                select_panelLayout.createParallelGroup()
                    .addComponent(scrollPane1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
            );
            select_panelLayout.setVerticalGroup(
                select_panelLayout.createParallelGroup()
                    .addComponent(scrollPane1, GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
            );
        }

        //======== bar_panel ========
        {

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);

            //---- exit ----
            exit.setText("exit");
            exit.addActionListener(e -> exitActionPerformed(e));

            GroupLayout bar_panelLayout = new GroupLayout(bar_panel);
            bar_panel.setLayout(bar_panelLayout);
            bar_panelLayout.setHorizontalGroup(
                bar_panelLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, bar_panelLayout.createSequentialGroup()
                        .addContainerGap(164, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addGap(145, 145, 145)
                        .addComponent(exit, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
            );
            bar_panelLayout.setVerticalGroup(
                bar_panelLayout.createParallelGroup()
                    .addGroup(bar_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(bar_panelLayout.createParallelGroup()
                            .addComponent(date)
                            .addGroup(bar_panelLayout.createSequentialGroup()
                                .addComponent(exit, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(1, 1, 1)))
                        .addContainerGap())
            );
        }

        //======== basicinfo_panel ========
        {

            //======== scrollPane2 ========
            {

                //---- basic_info_input ----
                basic_info_input.setEditable(false);
                scrollPane2.setViewportView(basic_info_input);
            }

            GroupLayout basicinfo_panelLayout = new GroupLayout(basicinfo_panel);
            basicinfo_panel.setLayout(basicinfo_panelLayout);
            basicinfo_panelLayout.setHorizontalGroup(
                basicinfo_panelLayout.createParallelGroup()
                    .addGroup(basicinfo_panelLayout.createSequentialGroup()
                        .addComponent(scrollPane2, GroupLayout.PREFERRED_SIZE, 531, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 1, Short.MAX_VALUE))
            );
            basicinfo_panelLayout.setVerticalGroup(
                basicinfo_panelLayout.createParallelGroup()
                    .addComponent(scrollPane2, GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)
            );
        }

        //======== system_panel ========
        {

            //---- system_switch_RadioButton ----
            system_switch_RadioButton.setText("\u5f00/\u5173");

            //---- system_switch_label ----
            system_switch_label.setText("\u7cfb\u7edf\u5f00\u5173\uff1a");

            //---- use_state_label ----
            use_state_label.setText("\u4f7f\u7528\u72b6\u6001\uff1a");

            //---- use_state_input ----
            use_state_input.setEditable(false);

            //---- amount_label ----
            amount_label.setText("\u4f59\u989d\uff1a");

            GroupLayout system_panelLayout = new GroupLayout(system_panel);
            system_panel.setLayout(system_panelLayout);
            system_panelLayout.setHorizontalGroup(
                system_panelLayout.createParallelGroup()
                    .addGroup(system_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(system_switch_label)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(system_switch_RadioButton)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(use_state_label)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(use_state_input, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(amount_label)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(amount_input, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
            );
            system_panelLayout.setVerticalGroup(
                system_panelLayout.createParallelGroup()
                    .addGroup(system_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(system_panelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(system_switch_label)
                            .addComponent(system_switch_RadioButton)
                            .addComponent(use_state_label)
                            .addComponent(amount_label)
                            .addComponent(amount_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(use_state_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
        }

        //======== scrollPane3 ========
        {
            scrollPane3.setViewportView(log_table);
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap())
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(select_panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addComponent(bar_panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGroup(contentPaneLayout.createParallelGroup()
                                .addComponent(system_panel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(contentPaneLayout.createSequentialGroup()
                                    .addComponent(basicinfo_panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addComponent(scrollPane3))
                            .addContainerGap())))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                        .addComponent(select_panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addComponent(basicinfo_panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(system_panel, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(scrollPane3, GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bar_panel, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField job_number;
    private JPanel select_panel;
    private JScrollPane scrollPane1;
    private JPanel bar_panel;
    private JTextField date;
    private JButton exit;
    private JPanel basicinfo_panel;
    private JScrollPane scrollPane2;
    private JTextArea basic_info_input;
    private JPanel system_panel;
    private JRadioButton system_switch_RadioButton;
    private JLabel system_switch_label;
    private JLabel use_state_label;
    private JTextField use_state_input;
    private JLabel amount_label;
    private JTextField amount_input;
    private JScrollPane scrollPane3;
    private JTable log_table;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
