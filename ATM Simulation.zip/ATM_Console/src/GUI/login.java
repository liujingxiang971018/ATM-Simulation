/*
 * Created by JFormDesigner on Wed Nov 20 16:03:19 CST 2019
 */

package GUI;

import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.GroupLayout;
import javax.swing.border.LineBorder;

/**
 * @author liujingxiang
 */
public class login extends JFrame {

    public login() {
        initComponents();
        job_number_input.setBorder(BorderFactory.createLineBorder(Color.black));
        job_password_input.setBorder(BorderFactory.createLineBorder(Color.black));

    }

    private void reset_buttonActionPerformed(ActionEvent e) {
        job_number_input.setText(null);
        job_password_input.setText(null);
    }
    //查询数据库，若存在，则关闭当前页面，跳转到下一个页面
    private void confirm_buttonActionPerformed(ActionEvent e) {
        String job_number=job_number_input.getText();
        char[] job_password=job_password_input.getPassword();
        //先判断输入框中是否有值
        if(job_number==null || job_password==null){
            if(job_number==null){
                job_number_input.setBorder(BorderFactory.createLineBorder(Color.red));
            }else{
                job_password_input.setBorder(BorderFactory.createLineBorder(Color.red));
            }
        }else{
            connection c= new connection();
            Connection conn=c.CreateSqlConnection();
            //编写查询语句，判断工号是否存在数据表staff_info中，以及工号和密码是否对应
            String sql="Select * from staff_info where staff_id="+job_number;
            try{
                //创建statement类对象，用来执行SQL语句
                Statement statement=conn.createStatement();
                ResultSet rs=statement.executeQuery(sql);

                //如果为空，就弹出消息框
                if(!rs.next()){
                    JOptionPane.showMessageDialog(null,"输入工号有误");
                }else {
                    //rs.next();
                    String password=rs.getString("staff_password");

                    System.out.println(password+"输入值:"+new String(job_password));
                    if(!password.equals(new String(job_password))){
                        JOptionPane.showMessageDialog(null,"输入密码错误");
                    }else{
                        rs.close();
                        conn.close();
                        //关闭当前界面
                        dispose();
                        //传递工号
                        operate operater=new operate(job_number);
                        operater.setVisible(true);
                    }
                }
            }catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }
    //失去焦点时触发:判断是否是13位并且是数字
    private void job_number_inputFocusLost(FocusEvent e) {
        String job_number=job_number_input.getText();
        System.out.println(job_number.length());
        for (int i = 0; i < job_number.length(); i++) {
            if(!Character.isDigit(job_number.charAt(i))){
//                JOptionPane.showMessageDialog(null,"工号格式不满足,请输入纯数字");
                //文本颜色变红
                job_number_input.setForeground(Color.red);
                //边框变红
                job_number_input.setBorder(BorderFactory.createLineBorder(Color.red));
            }
        }
    }
    //获取焦点时触发，将前景颜色修改为黑色
    private void job_number_inputFocusGained(FocusEvent e) {
        job_number_input.setForeground(Color.black);
        job_number_input.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    //失去焦点时触发：密码长度不能低于6位，不能超过12位
    private void job_password_inputFocusLost(FocusEvent e) {
        char[] job_password=job_password_input.getPassword();
        if(job_password.length<6||job_password.length>12){
            job_password_input.setForeground(Color.red);
            job_password_input.setBorder(BorderFactory.createLineBorder(Color.red));
        }
    }
    //获取焦点时触发，将前景颜色修改为黑色
    private void job_password_inputFocusGained(FocusEvent e) {
        job_password_input.setForeground(Color.black);
        job_password_input.setBorder(BorderFactory.createLineBorder(Color.black));
    }

    private void job_password_inputKeyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            ActionEvent enter = null;
            confirm_buttonActionPerformed(enter);
        }
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        job_number_label = new JLabel();
        job_number_input = new JTextField();
        job_password_label = new JLabel();
        job_password_input = new JPasswordField();
        reset_button = new JButton();
        confirm_button = new JButton();
        nav = new JPanel();
        signal = new JTextField();

        //======== this ========
        setTitle("ATM Console");
        setResizable(false);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setBackground(Color.white);
        setForeground(SystemColor.textText);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        var contentPane = getContentPane();

        //---- job_number_label ----
        job_number_label.setText("\u5de5\u53f7\uff1a");

        //---- job_number_input ----
        job_number_input.setForeground(Color.black);
        job_number_input.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                job_number_inputFocusGained(e);
            }
            @Override
            public void focusLost(FocusEvent e) {
                job_number_inputFocusLost(e);
            }
        });

        //---- job_password_label ----
        job_password_label.setText("\u5bc6\u7801\uff1a");

        //---- job_password_input ----
        job_password_input.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                job_password_inputFocusGained(e);
            }
            @Override
            public void focusLost(FocusEvent e) {
                job_password_inputFocusLost(e);
            }
        });
        job_password_input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                job_password_inputKeyPressed(e);
            }
        });

        //---- reset_button ----
        reset_button.setText("\u91cd\u7f6e");
        reset_button.addActionListener(e -> reset_buttonActionPerformed(e));

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");
        confirm_button.addActionListener(e -> confirm_buttonActionPerformed(e));

        //======== nav ========
        {

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c\u63a7\u5236\u53f0");
            signal.setEditable(false);
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getSize() + 4f));
            signal.setBackground(new Color(187, 187, 187));
            signal.setHorizontalAlignment(SwingConstants.CENTER);

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addComponent(signal, GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addComponent(signal, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
            );
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addContainerGap(235, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                .addComponent(job_password_label, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
                                .addComponent(job_number_label, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(contentPaneLayout.createParallelGroup()
                                .addComponent(job_password_input, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
                                .addComponent(job_number_input, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)))
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addComponent(reset_button)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(confirm_button)))
                    .addGap(218, 218, 218))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(114, 114, 114)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(job_number_label, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                        .addComponent(job_number_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addComponent(job_password_label, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                        .addComponent(job_password_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(40, 40, 40)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(confirm_button)
                        .addComponent(reset_button))
                    .addContainerGap(146, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JLabel job_number_label;
    private JTextField job_number_input;
    private JLabel job_password_label;
    private JPasswordField job_password_input;
    private JButton reset_button;
    private JButton confirm_button;
    private JPanel nav;
    private JTextField signal;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
