import GUI.*;
import sql.*;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ATM_Client_Main {
    public static void main(String[] args) {
        /*
        * 初始化：把信息写入到本地文件中保存，供下次启动时读取
        * */
        File f=new File("init.txt");

        if(f.exists()!=true){
            init_atmInfo init=new init_atmInfo();
            init.setVisible(true);
        }else{
            //初始化该ATM机
            //先判断ATM是否打开，若打开，则可操作
            connection c=new connection();
            Connection conn=c.CreateSqlConnection();
            String selectSql="select * from atm.atm_info where atm_id="+atm_info.getAtm_id();
            try {
                Statement statement=conn.createStatement();
                ResultSet rs=statement.executeQuery(selectSql);
                rs.next();
                boolean switch_flag=rs.getBoolean("switch_flag");
                if(switch_flag==true){
                    input_card card=new input_card();
                    card.setVisible(true);
                }else{
                    close closePage=new close();
                    closePage.setVisible(true);
                }
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
