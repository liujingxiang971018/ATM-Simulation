/*
 * Created by JFormDesigner on Wed Nov 20 15:36:55 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author liujingxiang
 */
public class success extends JFrame {
    public success(String card,String[] receipt) {
        initComponents();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                }
            }
        });
        DATE.start();

        //信息框输出信息
        switch (receipt[4]){
            case "deposit":
                String deposit_message = "——————存款成功——————\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                message_input.setText(deposit_message);
                break;
            case "withdrawal":
                String withdrawal_message = "——————取款成功——————\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                message_input.setText(withdrawal_message);
                break;
            case "transfer":
                String transfer_message = "——————转账成功——————\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                message_input.setText(transfer_message);
                break;
            case "charge":
                String charge_message = "——————充值成功——————\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                message_input.setText(charge_message);
                break;
            case "payment":
                String payment_message = "——————缴费成功——————\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                message_input.setText(payment_message);
                break;
        }

        back_button.addActionListener(e->back_buttonActionPerformed(e,card,-1));//默认返回index界面
        return_button.addActionListener(e->return_buttonActionPerformed(e));
        print_button.addActionListener(e->print_buttonActionPerformed(e,receipt));
    }

    private void back_buttonActionPerformed(ActionEvent e,String card,int state) {
        if(state==0) {
            JOptionPane.showMessageDialog(null, "操作超时，请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
            //返回银行卡插入页面
            dispose();
            input_card cardPage = new input_card();
            cardPage.setVisible(true);
            //TIME.stop();
        }else{
            //返回index界面
            dispose();
            index indexPage=new index(card);
            indexPage.setVisible(true);
            //TIME.stop();
        }
    }

    private void print_buttonActionPerformed(ActionEvent e,String[] receipt) {
        switch (receipt[4]){
            case "deposit":
                Object deposit_message="——————存款成功——————\n"+"交易编号："+receipt[0]+"\n"+"交易时间："+receipt[1]+"\n"+"交易地点："+receipt[3]+"\n"+"交易类型："+receipt[4]+"\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                JOptionPane.showMessageDialog(this,deposit_message,"receipt",JOptionPane.INFORMATION_MESSAGE);
                break;
            case "withdrawal":
                Object withdrawal_message="——————取款成功——————\n"+"交易编号："+receipt[0]+"\n"+"交易时间："+receipt[1]+"\n"+"交易地点："+receipt[3]+"\n"+"交易类型："+receipt[4]+"\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                JOptionPane.showMessageDialog(this,withdrawal_message,"receipt",JOptionPane.INFORMATION_MESSAGE);
                break;
            case "transfer":
                Object transfer_message="——————转账成功——————\n"+"交易编号："+receipt[0]+"\n"+"交易时间："+receipt[1]+"\n"+"交易地点："+receipt[3]+"\n"+"交易类型："+receipt[4]+"\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                JOptionPane.showMessageDialog(this,transfer_message,"receipt",JOptionPane.INFORMATION_MESSAGE);
                break;
            case "charge":
                Object charge_message="——————充值成功——————\n"+"交易编号："+receipt[0]+"\n"+"交易时间："+receipt[1]+"\n"+"交易地点："+receipt[3]+"\n"+"交易类型："+receipt[4]+"\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                JOptionPane.showMessageDialog(this,charge_message,"receipt",JOptionPane.INFORMATION_MESSAGE);
                break;
            case "payment":
                Object payment_message="——————缴费成功——————\n"+"交易编号："+receipt[0]+"\n"+"交易时间："+receipt[1]+"\n"+"交易地点："+receipt[3]+"\n"+"交易类型："+receipt[4]+"\n" + "户  主：" + receipt[5] + "\n" + "交易账户：" + receipt[6]+"\n"+"交易金额："+receipt[8]+"\n"+"剩余金额："+receipt[9]+"\n"+"————————--————————";
                JOptionPane.showMessageDialog(this,payment_message,"receipt",JOptionPane.INFORMATION_MESSAGE);
                break;
        }
    }

    private void return_buttonActionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+true+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        //TIME.stop();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        date = new JTextField();
        back_button = new JButton();
        return_button = new JButton();
        print_button = new JButton();
        _panel = new JScrollPane();
        message_input = new JTextArea();

        //======== this ========
        setTitle("ATM");
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));
            date.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 220, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
            );
        }

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        //---- print_button ----
        print_button.setText("\u6253\u5370");

        //======== _panel ========
        {

            //---- message_input ----
            message_input.setText("\u4fe1\u606f\u8f93\u51fa\u6846");
            message_input.setEditable(false);
            _panel.setViewportView(message_input);
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGap(121, 121, 121)
                    .addComponent(_panel, GroupLayout.PREFERRED_SIZE, 207, GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 150, Short.MAX_VALUE))
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addGap(0, 400, Short.MAX_VALUE)
                    .addComponent(print_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                    .addComponent(_panel, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
                    .addGap(8, 8, 8)
                    .addComponent(print_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(22, 22, 22))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField date;
    private JButton back_button;
    private JButton return_button;
    private JButton print_button;
    private JScrollPane _panel;
    private JTextArea message_input;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
