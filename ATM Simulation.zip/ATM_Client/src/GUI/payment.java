/*
 * Created by JFormDesigner on Wed Nov 20 15:49:22 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.event.ChangeListener;

/**
 * @author liujingxiang
 */
public class payment extends JFrame {
    long finalTime=60;

    public payment(String card,String type) {
        initComponents();
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));

                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();

        //查询违章表vehicle_violation_info中违章信息,并填充在信息栏中
        JPanel panel=select_vehicle_illegal(card);


        confirm_button.addActionListener(e->confirm_buttonActionPerformed(e,card,type,panel,TIME));
        back_button.addActionListener(e->back_buttonActionPerformed(e,card,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));
    }

    private JPanel select_vehicle_illegal(String card){
        JPanel panel1=new JPanel();

        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectOwnerIdSql="select * from atm.card_info where card_id="+card;
        try {
            Statement statement=conn.createStatement();
            ResultSet rsOwnerId=statement.executeQuery(selectOwnerIdSql);
            rsOwnerId.next();
            String ownerId=rsOwnerId.getString("owner_id");
            rsOwnerId.close();
            String selectIllegalSql="select * from atm.vehicle_violation_info where owner_id="+"'"+ownerId+"'";
            ResultSet rsIllegal=statement.executeQuery(selectIllegalSql);
            //获取违章个数
            int count=0;
            while(rsIllegal.next()){
                count++;
            }
            panel1.setLayout(new GridLayout(4,1));
            rsIllegal.beforeFirst();
            for (int i = 0; i < count; i++) {
                rsIllegal.next();
                String violation_id=rsIllegal.getString("violation_id");
                String vehicle_license=rsIllegal.getString("vehicle_license");
                String date=rsIllegal.getString("violation_date");
                String violation_type=rsIllegal.getString("violation_type");
                String penalty_amount=rsIllegal.getString("penalty_amount");
                System.out.println(vehicle_license+" "+date+" "+violation_type);

                JCheckBox jCheckBox=new JCheckBox(violation_id+" "+vehicle_license+" "+violation_type+" "+penalty_amount+"\n");
                panel1.add(jCheckBox);

                jCheckBox.addActionListener(e->checkChangedPerformed(e,jCheckBox,ownerId,violation_id));
            }

            scrollPane1.getViewport().add(panel1);
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return panel1;
    }

    //选择后事件：显示详细信息
    private void checkChangedPerformed(ActionEvent e,JCheckBox jCheckBox,String ownerid, String violation_id){
        if(jCheckBox.isSelected()){
            connection c=new connection();
            Connection conn=c.CreateSqlConnection();
            String selectSql="select * from atm.vehicle_violation_info where owner_id="+"'"+ownerid+"'"+"and violation_id="+"'"+violation_id+"'";
            try {
                Statement statement=conn.createStatement();
                ResultSet rs=statement.executeQuery(selectSql);
                rs.next();
                String owner_name=rs.getString(3);
                String vehicle_license=rs.getString(4);
                String violation_date=rs.getString(5);
                String violation_location=rs.getString(6);
                String violation_type=rs.getString(7);
                String penalty_amount=rs.getString(8);
                String penalty_fraction=rs.getString(9);

                String message="车   主："+owner_name+"\n"+"车牌号码："+vehicle_license+"\n"+"违章时间："+violation_date+"\n"+"违章地点："+violation_location+"\n"+"违章类型："+violation_type+"\n"+"罚款金额："+penalty_amount+"\n"+"罚款分数："+penalty_fraction+"\n";
                JOptionPane.showMessageDialog(this,message,"details",JOptionPane.INFORMATION_MESSAGE);
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void back_buttonActionPerformed(ActionEvent e,String card,Thread TIME) {
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
        TIME.stop();
    }
    //对选中的违章进行处理的确认事件
    //对etc钱包金额进行修改，删除违章记录
    private void confirm_buttonActionPerformed(ActionEvent e,String card,String type,JPanel panel,Thread TIME) {

        int count=panel.getComponentCount();
        double amount=0;
        String selected_violationId="";
        for (int i = 0; i < count; i++) {
            Object object=panel.getComponent(i);
            if(object instanceof JCheckBox){
                boolean t=((JCheckBox)object).isSelected();
                if(t){
                    String[] message=((JCheckBox)object).getText().split(" ");
                    String violation_id=message[0];
                    String penalty_amount=message[3];
                    amount+=Double.valueOf(penalty_amount);
                    selected_violationId=selected_violationId+violation_id+" ";
                }
            }
        }
        System.out.println("amount="+amount);
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectCardSql="select * from atm.card_info where card_id="+card;
        try {
            Statement statement=conn.createStatement();
            ResultSet rsCard=statement.executeQuery(selectCardSql);
            rsCard.next();
            String ETC_amount=rsCard.getString("etc_amount");
            if(Double.valueOf(ETC_amount)<amount){
                JOptionPane.showMessageDialog(this,"钱包余额不足，请先充值...","ERROR",JOptionPane.ERROR_MESSAGE);
            }else{
                String ETC_newamount=String.valueOf(Double.valueOf(ETC_amount)-amount);

                String[] state=new String[]{type,selected_violationId,ETC_newamount,String.valueOf(amount)};//类型，违章id组成的字符串,ETC剩余金额，交易金额
                dispose();
                input_password inputPasswordPage=new input_password(card,state);
                inputPasswordPage.setVisible(true);
                TIME.stop();
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }



    }

    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        timer = new JTextField();
        date = new JTextField();
        back_button = new JButton();
        return_button = new JButton();
        confirm_button = new JButton();
        scrollPane1 = new JScrollPane();

        //======== this ========
        setTitle("ATM");
        setResizable(false);
        setBackground(Color.white);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- timer ----
            timer.setText("60");
            timer.setBackground(new Color(187, 187, 187));

            //---- date ----
            date.setText("2019.1.17 11:11:11");
            date.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))
            );
        }

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addContainerGap(75, Short.MAX_VALUE)
                    .addComponent(scrollPane1, GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(confirm_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 190, Short.MAX_VALUE)
                            .addComponent(confirm_button)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED))
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGap(29, 29, 29)
                            .addComponent(scrollPane1, GroupLayout.PREFERRED_SIZE, 155, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)))
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(29, 29, 29))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField timer;
    private JTextField date;
    private JButton back_button;
    private JButton return_button;
    private JButton confirm_button;
    private JScrollPane scrollPane1;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
