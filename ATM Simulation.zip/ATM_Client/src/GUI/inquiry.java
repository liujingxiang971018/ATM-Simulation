/*
 * Created by JFormDesigner on Wed Nov 20 15:17:12 CST 2019
 */

package GUI;

import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
public class inquiry extends JFrame {
    long finalTime=60;

    public inquiry(String card) {
        initComponents();
        //倒计时
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));

                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();

        back_button.addActionListener(e->back_buttonActionPerformed(e,card,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));

        //直接查询账户余额，然后显示在message文本框中
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectSql="select * from atm.card_info where card_id="+"'"+card+"'";
        try {
            Statement statement=conn.createStatement();
            ResultSet rs=statement.executeQuery(selectSql);
            rs.next();
            String owner_name=rs.getString("owner_name");
            String newName=owner_name.replace(owner_name.charAt(0),'*');
            String avail_amount=rs.getString("avail_amount");
            String etc_amount=rs.getString("etc_amount");
            String Message="户主："+newName+"\n\n"+"账户余额："+avail_amount+"元"+"\n\n"+"ETC余额："+etc_amount+"元"+"\n";
            message.setText(Message);
            rs.close();
            conn.close();
        } catch (SQLException e) {
            e.getMessage();
        }

    }

    private void back_buttonActionPerformed(ActionEvent e,String card,Thread TIME) {
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
        TIME.stop();
    }

    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        timer = new JTextField();
        date = new JTextField();
        back_button = new JButton();
        return_button = new JButton();
        message = new JTextArea();

        //======== this ========
        setTitle("ATM");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- timer ----
            timer.setText("60");
            timer.setBackground(new Color(187, 187, 187));
            timer.setFont(timer.getFont().deriveFont(timer.getFont().getSize() + 1f));

            //---- date ----
            date.setText("2019.1.17 11:11:11");
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))
            );
        }

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        //---- message ----
        message.setEditable(false);

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGap(165, 165, 165)
                    .addComponent(message, GroupLayout.PREFERRED_SIZE, 143, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(170, Short.MAX_VALUE))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                    .addComponent(message, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
                    .addGap(57, 57, 57)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(27, 27, 27))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField timer;
    private JTextField date;
    private JButton back_button;
    private JButton return_button;
    private JTextArea message;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
