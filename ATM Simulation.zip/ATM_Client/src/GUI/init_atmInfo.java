/*
 * Created by JFormDesigner on Mon Dec 02 20:15:25 CST 2019
 */

package GUI;

import sql.*;

import java.awt.*;
import java.awt.event.*;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import javax.swing.*;
import javax.swing.GroupLayout;


/**
 * @author liujingxiang
 */
public class init_atmInfo extends JFrame {
    public init_atmInfo() {
        initComponents();
        ATM_location();
        SetLocalIp();
    }
    private void ATM_location(){
        String[] Province=new String[]{"四川","北京","上海","重庆"};
        String[] City=new String[]{"成都","绵阳","南充","内江"};
        String[] County=new String[]{"武侯","青羊","锦江","金牛"};
        String[] Street=new String[]{"望江路街道","玉林街道","双楠街道","簇桥街道"};
        String[] Area=new String[]{"四川大学点","磨子桥点","红瓦寺点"};
        for (int i = 0; i < Province.length; i++) {
            province.addItem(Province[i]);
        }
        for (int j = 0; j < City.length; j++) {
            city.addItem(City[j]);
        }
        for (int k = 0; k < County.length; k++) {
            county.addItem(County[k]);
        }
        for (int m = 0; m < Street.length; m++) {
            street.addItem(Street[m]);
        }
        for (int n = 0; n < Area.length; n++) {
            area.addItem(Area[n]);
        }
    }
    //获取本机真实IP
    private void SetLocalIp(){
        try {
            Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
            while (allNetInterfaces.hasMoreElements()) {
                NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();

                // 去除回环接口，子接口，未运行和接口
                if (netInterface.isLoopback() || netInterface.isVirtual() || !netInterface.isUp()) {
                    continue;
                }

                if (!netInterface.getDisplayName().contains("Intel") && !netInterface.getDisplayName().contains("Realtek") && !netInterface.getDisplayName().contains("Broadcom")) {
                    continue;
                }
                Enumeration<InetAddress> addresses = netInterface.getInetAddresses();
                System.out.println(netInterface.getDisplayName());
                while (addresses.hasMoreElements()) {
                    InetAddress ip = addresses.nextElement();
                    if (ip != null) {
                        // ipv4
                        if (ip instanceof Inet4Address) {
                            System.out.println("ipv4 = " + ip.getHostAddress());
                            atmip_input.setText(ip.getHostAddress());
                        }
                    }
                }
                break;
            }
        } catch (SocketException e) {
            System.err.println("Error when getting host ip address" + e.getMessage());
        }
    }

    //获取文本，创建数据记录
    private void confirm_buttonActionPerformed(ActionEvent e) {
        String atmid=atmid_input.getText();
        String atmlocation=province.getSelectedItem()+"-"+city.getSelectedItem()+"-"+county.getSelectedItem()+"-"+street.getSelectedItem()+"-"+area.getSelectedItem();
        String atmname=atmname_input.getText();
        String atmip=atmip_input.getText();
        String atmamount=atmamount_input.getText();
        System.out.println(atmlocation);
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String insertSql="insert into atm.atm_info(atm_id,atm_location,atm_name,atm_networknumber,avail_amount) values("+"'"+atmid+"'"+","+"'"+atmlocation+"'"+","+"'"+atmname+"'"+","+"'"+atmip+"'"+","+"'"+atmamount+"'"+")";
        try {
            Statement statement=conn.createStatement();
            statement.executeUpdate(insertSql);
            conn.close();
            //将atm编号保存到全局信息atm_info中
            atm_info.setAtm(atmid,atmlocation+" "+atmname);

            //跳转页面
            dispose();
            input_card card=new input_card();
            card.setVisible(true);

        } catch (SQLException ex) {
            ex.getMessage();
        }

    }

    private void confirm_buttonKeyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER){
            ActionEvent click = null;
            confirm_buttonActionPerformed(click);
        }
    }



    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        label1 = new JLabel();
        atmid_label = new JLabel();
        atmid_input = new JTextField();
        atmlocation_label = new JLabel();
        province = new JComboBox();
        city = new JComboBox();
        county = new JComboBox();
        street = new JComboBox();
        area = new JComboBox();
        atmname_label = new JLabel();
        atmname_input = new JTextField();
        atmip_label = new JLabel();
        atmip_input = new JTextField();
        atmamount_label = new JLabel();
        atmamount_input = new JTextField();
        confirm_button = new JButton();

        //======== this ========
        setBackground(Color.white);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ATM");
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() & ~Font.BOLD, signal.getFont().getSize() + 4f));

            //---- label1 ----
            label1.setText("ATM\u673a\u521d\u59cb\u5316\u4fe1\u606f");
            label1.setFont(label1.getFont().deriveFont(label1.getFont().getSize() + 3f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(label1)
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(label1, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))
            );
        }

        //---- atmid_label ----
        atmid_label.setText("ATM\u7f16\u53f7\uff1a");

        //---- atmlocation_label ----
        atmlocation_label.setText("ATM\u4f4d\u7f6e\uff1a");

        //---- atmname_label ----
        atmname_label.setText("ATM\u540d\u79f0\uff1a");

        //---- atmip_label ----
        atmip_label.setText("ATM\u673aIP\uff1a");

        //---- atmip_input ----
        atmip_input.setEditable(false);

        //---- atmamount_label ----
        atmamount_label.setText("ATM\u4f59\u989d\uff1a");

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");
        confirm_button.addActionListener(e -> confirm_buttonActionPerformed(e));
        confirm_button.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                confirm_buttonKeyPressed(e);
            }
        });

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGap(59, 59, 59)
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addComponent(atmid_label)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(atmid_input, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
                            .addGap(14, 255, Short.MAX_VALUE))
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                .addComponent(atmamount_label, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(atmname_label, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(atmlocation_label, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(atmip_label, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(contentPaneLayout.createParallelGroup()
                                .addGroup(contentPaneLayout.createSequentialGroup()
                                    .addComponent(province, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(city, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(county, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(street, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(area, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
                                .addGroup(contentPaneLayout.createSequentialGroup()
                                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(atmamount_input, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                        .addComponent(atmip_input, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                        .addComponent(atmname_input, GroupLayout.Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE))
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 177, Short.MAX_VALUE)
                                    .addComponent(confirm_button))))))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(33, 33, 33)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(atmid_label, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                        .addComponent(atmid_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(atmlocation_label, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                        .addComponent(province, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(city, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(county, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(street, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(area, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(atmname_label, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                        .addComponent(atmname_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(atmip_label, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                        .addComponent(atmip_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(atmamount_label, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
                                .addComponent(atmamount_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                            .addGap(0, 43, Short.MAX_VALUE))
                        .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                            .addComponent(confirm_button)
                            .addGap(31, 31, 31))))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JLabel label1;
    private JLabel atmid_label;
    private JTextField atmid_input;
    private JLabel atmlocation_label;
    private JComboBox province;
    private JComboBox city;
    private JComboBox county;
    private JComboBox street;
    private JComboBox area;
    private JLabel atmname_label;
    private JTextField atmname_input;
    private JLabel atmip_label;
    private JTextField atmip_input;
    private JLabel atmamount_label;
    private JTextField atmamount_input;
    private JButton confirm_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
