/*
 * Created by JFormDesigner on Wed Nov 20 14:41:16 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
public class index extends JFrame {
    public index(String card) {
        initComponents();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));

                }
            }
        });
        DATE.start();

        inquiry_button.addActionListener(e->inquiry_buttonActionPerformed(e,card));
        withdrawl_button.addActionListener(e->withdrawl_buttonActionPerformed(e,card));
        deposit_button.addActionListener(e->deposit_buttonActionPerformed(e,card));
        transfer_button.addActionListener(e->transfer_buttonActionPerformed(e,card));
        charge_button.addActionListener(e->charge_buttonActionPerformed(e,card));
        payment_button.addActionListener(e->payment_buttonActionPerformed(e,card));
    }

    private void inquiry_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        inquiry inquiryPage=new inquiry(card);
        inquiryPage.setVisible(true);
    }

    private void deposit_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        deposit depositPage=new deposit(card,"1");
        depositPage.setVisible(true);
    }

    private void withdrawl_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        withdrawal withdrawalPage=new withdrawal(card,"2");
        withdrawalPage.setVisible(true);
    }

    private void transfer_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        transfer transferPage=new transfer(card,"3");
        transferPage.setVisible(true);
    }

    private void charge_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        charge chargePage=new charge(card,"4");
        chargePage.setVisible(true);
    }

    private void payment_buttonActionPerformed(ActionEvent e,String card) {
        dispose();
        payment paymentPage=new payment(card,"5");
        paymentPage.setVisible(true);
    }

    private void return_buttonActionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
    }



    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        date = new JTextField();
        inquiry_button = new JButton();
        withdrawl_button = new JButton();
        deposit_button = new JButton();
        transfer_button = new JButton();
        charge_button = new JButton();
        payment_button = new JButton();
        return_button = new JButton();

        //======== this ========
        setTitle("ATM");
        setResizable(false);
        setBackground(Color.white);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));
            date.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
        }

        //---- inquiry_button ----
        inquiry_button.setText("\u67e5\u8be2");

        //---- withdrawl_button ----
        withdrawl_button.setText("\u53d6\u6b3e");

        //---- deposit_button ----
        deposit_button.setText("\u5b58\u6b3e");

        //---- transfer_button ----
        transfer_button.setText("\u8f6c\u8d26");

        //---- charge_button ----
        charge_button.setText("ETC\u5145\u503c");

        //---- payment_button ----
        payment_button.setText("\u8fdd\u7ae0\u7f34\u8d39");

        //---- return_button ----
        return_button.setText("\u9000\u5361");
        return_button.addActionListener(e -> return_buttonActionPerformed(e));

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addComponent(deposit_button)
                        .addComponent(transfer_button))
                    .addGap(0, 400, Short.MAX_VALUE))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(inquiry_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 320, Short.MAX_VALUE)
                    .addComponent(charge_button))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(withdrawl_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 318, Short.MAX_VALUE)
                    .addComponent(payment_button))
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addGap(0, 400, Short.MAX_VALUE)
                    .addComponent(return_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
                    .addGap(49, 49, 49)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(inquiry_button)
                        .addComponent(charge_button))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(withdrawl_button)
                        .addComponent(payment_button))
                    .addGap(18, 18, 18)
                    .addComponent(deposit_button)
                    .addGap(18, 18, 18)
                    .addComponent(transfer_button)
                    .addGap(18, 18, 18)
                    .addComponent(return_button)
                    .addContainerGap(16, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField date;
    private JButton inquiry_button;
    private JButton withdrawl_button;
    private JButton deposit_button;
    private JButton transfer_button;
    private JButton charge_button;
    private JButton payment_button;
    private JButton return_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
