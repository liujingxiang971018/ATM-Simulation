/*
 * Created by JFormDesigner on Wed Nov 20 10:49:34 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author liujingxiang
 */
public class close extends JFrame {
    public close() {
        initComponents();
        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                }
            }
        });
        DATE.start();

        //判定atm_info表中switch_flag字段是否为true
        Thread Close= new Thread(new Runnable() {
            @Override
            public void run() {
                String atm_id= atm_info.getAtm_id();
                connection c= new connection();
                Connection conn=c.CreateSqlConnection();
                String selectSql = "select * from atm.atm_info where atm_id =" + "'" + atm_id + "'";

                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //对atm_info表中switch_flag字段检查
                    Statement statement = null;
                    try {
                        statement = conn.createStatement();
                        ResultSet rs = statement.executeQuery(selectSql);
                        rs.next();
                        boolean switch_flag = rs.getBoolean("switch_flag");
                        if (switch_flag == true) {
                            dispose();
                            input_card inputCardPage = new input_card();
                            inputCardPage.setVisible(true);
                            break;
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
        Close.start();
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        close_label = new JLabel();
        nav = new JPanel();
        date = new JTextField();
        signal = new JTextField();

        //======== this ========
        setBackground(Color.white);
        setForeground(SystemColor.activeCaption);
        setTitle("ATM");
        setResizable(false);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //---- close_label ----
        close_label.setText("\u7cfb\u7edf\u6b63\u5728\u7ef4\u62a4\u4e2d\uff0c\u65e0\u6cd5\u4f7f\u7528...");
        close_label.setBackground(new Color(153, 0, 0));
        close_label.setFont(close_label.getFont().deriveFont(close_label.getFont().getSize() + 3f));

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 219, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            );
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGap(120, 120, 120)
                    .addComponent(close_label, GroupLayout.PREFERRED_SIZE, 216, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(142, Short.MAX_VALUE))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(112, 112, 112)
                    .addComponent(close_label, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(147, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JLabel close_label;
    private JPanel nav;
    private JTextField date;
    private JTextField signal;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
