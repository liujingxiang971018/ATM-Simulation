/*
 * Created by JFormDesigner on Wed Nov 20 15:43:36 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
public class charge extends JFrame {
    long finalTime=60;
    public charge(String card,String type) {
        initComponents();
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));

                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();
        moneycharge_button.addActionListener(e->moneycharge_buttonActionPerformed(e,card,type,TIME));
        amountcharge_button.addActionListener(e->amountcharge_buttonActionPerformed(e,card,type,TIME));
        back_button.addActionListener(e->back_buttonActionPerformed(e,card,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));
    }
    //相当于存款
    private void moneycharge_buttonActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        dispose();
        deposit depositPage=new deposit(card,type);
        depositPage.setVisible(true);
        TIME.stop();
    }
    //相当于存款
    private void amountcharge_buttonActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        dispose();
        deposit depositPage=new deposit(card,"-"+type);
        depositPage.setVisible(true);
        TIME.stop();
    }

    private void back_buttonActionPerformed(ActionEvent e,String card,Thread TIME) {
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
        TIME.stop();
    }

    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        singal = new JTextField();
        timer = new JTextField();
        date = new JTextField();
        moneycharge_button = new JButton();
        amountcharge_button = new JButton();
        back_button = new JButton();
        return_button = new JButton();

        //======== this ========
        setResizable(false);
        setTitle("ATM");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- singal ----
            singal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            singal.setEditable(false);
            singal.setBackground(new Color(187, 187, 187));
            singal.setFont(singal.getFont().deriveFont(singal.getFont().getStyle() | Font.BOLD, singal.getFont().getSize() + 3f));

            //---- timer ----
            timer.setText("60");
            timer.setBackground(new Color(187, 187, 187));
            timer.setFont(timer.getFont().deriveFont(timer.getFont().getSize() + 1f));

            //---- date ----
            date.setText("2019.1.17 11:11:11");
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));
            date.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(singal, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(singal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))
            );
        }

        //---- moneycharge_button ----
        moneycharge_button.setText("\u73b0\u91d1\u5145\u503c");

        //---- amountcharge_button ----
        amountcharge_button.setText("\u8d26\u6237\u5212\u6b3e");

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addComponent(moneycharge_button)
                        .addComponent(amountcharge_button))
                    .addGap(0, 396, Short.MAX_VALUE))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(43, 43, 43)
                    .addComponent(moneycharge_button)
                    .addGap(44, 44, 44)
                    .addComponent(amountcharge_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(28, 28, 28))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField singal;
    private JTextField timer;
    private JTextField date;
    private JButton moneycharge_button;
    private JButton amountcharge_button;
    private JButton back_button;
    private JButton return_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
