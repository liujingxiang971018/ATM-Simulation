/*
 * Created by JFormDesigner on Wed Nov 20 15:04:35 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

/**
 * @author liujingxiang
 */
public class input_card extends JFrame {
    public input_card() {
        initComponents();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                }
            }
        }).start();

        //判定atm_info表中switch_flag字段是否为false
        Thread judge=new Thread(new Runnable() {
            @Override
            public void run() {
                String atm_id=atm_info.getAtm_id();
                connection c = new connection();
                Connection conn = c.CreateSqlConnection();

                while (true) {
                    //对atm_info表中switch_flag字段检查
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    Statement statement = null;
                    try {
                        statement = conn.createStatement();
                        long startTime=System.currentTimeMillis();
                        String selectSql = "select * from atm.atm_info where atm_id =" + "'" + atm_id + "'";
                        ResultSet rs = statement.executeQuery(selectSql);
                        System.out.println("执行时间："+(System.currentTimeMillis()-startTime));
                        rs.next();
                        boolean switch_flag = rs.getBoolean("switch_flag");
                        System.out.println(switch_flag);
                        if (switch_flag == false) {
                            dispose();
                            close closePage = new close();
                            closePage.setVisible(true);
                            break;
                        }
                        rs.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
        judge.start();

        //只能输入数字，且限定长度
        card_input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                int key=e.getKeyChar();
                if(card_input.getText().length()<19){
                    if((key<KeyEvent.VK_0 || key>KeyEvent.VK_9) && key!=KeyEvent.VK_BACK_SPACE){
                        e.consume();
                    }
                }else{
                    e.consume();
                }
            }
        });
        confirm_button.addActionListener(e->confirm_buttonActionPerformed(e,judge));

    }

    private void reset_buttonActionPerformed(ActionEvent e) {
        card_input.setText(null);
    }
    //验证数据库中是否存在，若存在，则跳转到index页面
    private void confirm_buttonActionPerformed(ActionEvent e,Thread judge) {
        String card=card_input.getText();

        if(card.length()!=19){
            JOptionPane.showMessageDialog(this,"请输入正确长度的银行卡号...","Warning",JOptionPane.WARNING_MESSAGE);
        }else{
            connection c=new connection();
            Connection conn=c.CreateSqlConnection();
            String selectSql="select * from atm.card_info where card_id = "+"'"+card+"'";
            try {
                Statement statement=conn.createStatement();
                ResultSet rs=statement.executeQuery(selectSql);
                //如果存在，则跳转到input_password页面
                if(rs.next()){
                    System.out.println(rs.getString("card_id"));
                    judge.stop();
                    dispose();
                    String[] state=new String[]{"0"};
                    input_password passwordPage=new input_password(card,state);
                    passwordPage.setVisible(true);
                }else{
                    //如果不存在，则弹出信息框
                    JOptionPane.showMessageDialog(this,"此卡已无效...","ERROR",JOptionPane.ERROR_MESSAGE);
                }
                rs.close();
                conn.close();
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }

    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        date = new JTextField();
        signal = new JTextField();
        card_label = new JLabel();
        card_input = new JTextField();
        reset_button = new JButton();
        confirm_button = new JButton();

        //======== this ========
        setTitle("ATM");
        setResizable(false);
        setBackground(Color.white);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() & ~Font.BOLD, signal.getFont().getSize() + 3f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 220, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
            );
        }

        //---- card_label ----
        card_label.setText("     \u8bf7\u63d2\u5165\u5361\u7247...");
        card_label.setFont(card_label.getFont().deriveFont(card_label.getFont().getSize() + 1f));

        //---- reset_button ----
        reset_button.setText("\u66f4\u6b63");
        reset_button.addActionListener(e -> reset_buttonActionPerformed(e));

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addContainerGap(145, Short.MAX_VALUE)
                    .addComponent(card_input, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(153, Short.MAX_VALUE))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGap(180, 180, 180)
                    .addComponent(card_label, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(179, Short.MAX_VALUE))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(reset_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(confirm_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                    .addComponent(card_label, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(card_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(81, 81, 81)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(confirm_button)
                        .addComponent(reset_button))
                    .addGap(43, 43, 43))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField date;
    private JTextField signal;
    private JLabel card_label;
    private JTextField card_input;
    private JButton reset_button;
    private JButton confirm_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
