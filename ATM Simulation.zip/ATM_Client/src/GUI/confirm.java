/*
 * Created by JFormDesigner on Sat Dec 07 21:25:56 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.GroupLayout;

/**
 * @author liujingxiang
 */
public class confirm extends JFrame {
    public confirm(String card,String[] state) {
        initComponents();
        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                }
            }
        });
        DATE.start();

        //展示信息在信息框
        //先查询目标账户的姓名
        //获取户主名：
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectNameSql = "select * from atm.card_info where card_id=" + "'" + state[1] + "'";

        Statement statement= null;
        try {
            statement = conn.createStatement();
            ResultSet rsName = statement.executeQuery(selectNameSql);
            rsName.next();
            String owner_name = rsName.getString("owner_name");
            String newName = owner_name.replace(owner_name.charAt(0), '*');
            message_input.setText("——————转账确认——————\n\n"+"对方账号："+state[1]+"\n\n"+"对方姓名："+newName+"\n\n"+"交易金额："+state[3]+"\n————————-————————\n");
            rsName.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        back_button.addActionListener(e->back_buttonActionPerformed(e,card));//默认返回index界面
        return_button.addActionListener(e->return_buttonActionPerformed(e));
        confirm_button.addActionListener(e->confirm_buttonActionPerformed(e,card,state));

    }

    private void back_buttonActionPerformed(ActionEvent e,String card) {
        //返回index界面
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
    }

    private void return_buttonActionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+true+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
    }

    private void confirm_buttonActionPerformed(ActionEvent e,String card,String[] state) {
        dispose();
        input_password inputPasswordPage=new input_password(card,state);
        inputPasswordPage.setVisible(true);
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        date = new JTextField();
        message_input = new JTextArea();
        back_button = new JButton();
        confirm_button = new JButton();
        return_button = new JButton();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setResizable(false);
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));
            date.setBackground(new Color(187, 187, 187));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 220, Short.MAX_VALUE)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
            );
        }

        //---- message_input ----
        message_input.setText("\u4fe1\u606f\u8f93\u51fa\u6846");
        message_input.setEditable(false);

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createParallelGroup()
                    .addGroup(contentPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(message_input, GroupLayout.PREFERRED_SIZE, 205, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addGap(0, 400, Short.MAX_VALUE)
                    .addComponent(confirm_button))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createParallelGroup()
                    .addGroup(contentPaneLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(message_input, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 195, Short.MAX_VALUE)
                    .addComponent(confirm_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(return_button)
                        .addComponent(back_button))
                    .addGap(20, 20, 20))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField date;
    private JTextArea message_input;
    private JButton back_button;
    private JButton confirm_button;
    private JButton return_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
