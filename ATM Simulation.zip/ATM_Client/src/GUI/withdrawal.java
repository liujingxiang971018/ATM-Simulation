/*
 * Created by JFormDesigner on Wed Nov 20 14:56:39 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
public class withdrawal extends JFrame {
    long finalTime=60;
    public withdrawal(String card,String type) {
        initComponents();
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));

                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();

        back_button.addActionListener(e->back_buttonActionPerformed(e,card,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));
        button_100.addActionListener(e->button_100ActionPerformed(e,card,type,TIME));
        button_200.addActionListener(e->button_200ActionPerformed(e,card,type,TIME));
        button_300.addActionListener(e->button_300ActionPerformed(e,card,type,TIME));
        button_500.addActionListener(e->button_500ActionPerformed(e,card,type,TIME));
        button_1000.addActionListener(e->button_1000ActionPerformed(e,card,type,TIME));
        button_2000.addActionListener(e->button_2000ActionPerformed(e,card,type,TIME));
    }

    private void back_buttonActionPerformed(ActionEvent e,String card,Thread TIME) {
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
        TIME.stop();
    }

    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();
    }

    private void withdrawl_actionPerformed(String amount,String card,String type,Thread TIME){
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectAtmSql="select * from atm.atm_info where atm_id="+"'"+ atm_info.getAtm_id()+"'";
        try {
            Statement statement=conn.createStatement();
            ResultSet rs=statement.executeQuery(selectAtmSql);
            rs.next();
            String Atmavail_amount=rs.getString("avail_amount");
            //ATM机中余额不够
            if(Double.valueOf(Atmavail_amount)<Double.valueOf(amount)){
                JOptionPane.showMessageDialog(this,"ATM机中余额不足...","ERROR",JOptionPane.ERROR_MESSAGE);
            }else{
                String selectCardSql="select * from atm.card_info where card_id="+"'"+card+"'";
                ResultSet rsCard=statement.executeQuery(selectCardSql);
                rsCard.next();
                String CardAvail_amount=rsCard.getString("avail_amount");
                if(Double.valueOf(CardAvail_amount)<Double.valueOf(amount)){
                    JOptionPane.showMessageDialog(this,"银行卡余额不足...","ERROR",JOptionPane.ERROR_MESSAGE);
                }else{
                    String Atmnew_amount=String.valueOf(Double.valueOf(Atmavail_amount)-Double.valueOf(amount));
                    String Cardnew_amount=String.valueOf(Double.valueOf(CardAvail_amount)-Double.valueOf(amount));
                    dispose();
                    String[] state=new String[]{type,Atmnew_amount,Cardnew_amount,amount};//类型、ATM剩余金额，银行卡剩余金额，交易金额
                    input_password passwordPage=new input_password(card,state);
                    passwordPage.setVisible(true);
                    TIME.stop();
                }
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    //先判定卡里余额是否足够，再判定ATM机中余额是否足够
    private void button_100ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("100",card,type,TIME);
    }

    private void button_200ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("200",card,type,TIME);
    }

    private void button_300ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("300",card,type,TIME);
    }

    private void button_500ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("500",card,type,TIME);
    }

    private void button_1000ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("1000",card,type,TIME);
    }

    private void button_2000ActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        withdrawl_actionPerformed("2000",card,type,TIME);
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        signal = new JTextField();
        timer = new JTextField();
        date = new JTextField();
        button_100 = new JButton();
        button_200 = new JButton();
        button_300 = new JButton();
        back_button = new JButton();
        button_500 = new JButton();
        button_1000 = new JButton();
        button_2000 = new JButton();
        return_button = new JButton();

        //======== this ========
        setResizable(false);
        setTitle("ATM");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- timer ----
            timer.setText("60");
            timer.setBackground(new Color(187, 187, 187));
            timer.setFont(timer.getFont().deriveFont(timer.getFont().getSize() + 1f));

            //---- date ----
            date.setText("2019.1.17 11:11:11");
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 125, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))
            );
        }

        //---- button_100 ----
        button_100.setText("100");

        //---- button_200 ----
        button_200.setText("200");

        //---- button_300 ----
        button_300.setText("300");

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- button_500 ----
        button_500.setText("500");

        //---- button_1000 ----
        button_1000.setText("1000");

        //---- button_2000 ----
        button_2000.setText("2000");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(button_100)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(button_500))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(button_200)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(button_1000))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(button_300)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(button_2000))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(41, 41, 41)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(button_100)
                        .addComponent(button_500))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(button_200)
                        .addComponent(button_1000))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(button_300)
                        .addComponent(button_2000))
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(24, 24, 24))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField signal;
    private JTextField timer;
    private JTextField date;
    private JButton button_100;
    private JButton button_200;
    private JButton button_300;
    private JButton back_button;
    private JButton button_500;
    private JButton button_1000;
    private JButton button_2000;
    private JButton return_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
