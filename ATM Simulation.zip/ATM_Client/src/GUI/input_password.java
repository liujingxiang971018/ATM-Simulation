/*
 * Created by JFormDesigner on Wed Nov 20 14:21:48 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
/*
* state=0:来自卡插入界面
* state=1:来自存款界面
* state=2：来自取款界面
* state=3：来自转账界面
* state=4：来自充值界面
* state=5：来自缴费界面
* */
public class input_password extends JFrame {

    private int wrong_Time=3;//输入密码容错次数
    private long finalTime=60;//初始化为60秒

    public input_password(String card,String[] state) {
        initComponents();

        if(state[0]=="0"){
            back_button.setVisible(false);
        }else{
            back_button.setVisible(true);
        }

        //倒计时
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,state,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();

        //只能输入数字，且限定长度
        password_input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                int key=e.getKeyChar();
                if(password_input.getText().length()<6){
                    if((key<KeyEvent.VK_0 || key>KeyEvent.VK_9) && key!=KeyEvent.VK_BACK_SPACE){
                        e.consume();
                    }
                }else{
                    e.consume();
                }
            }
        });

        connection c= new connection();
        Connection conn=c.CreateSqlConnection();
        String updateSql="update atm.atm_info set state_flag = "+true+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
        //对atm_info表中state_flag字段更新
        try {
            Statement statement=conn.createStatement();
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        confirm_button.addActionListener(e->confirm_buttonActionPerformed(e,card,state,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));
        back_button.addActionListener(e->back_buttonActionPerformed(e,card,state,TIME));
    }

    //执行确认密码后的存款、取款、充值等操作
    private void actionPerformed(String type,String card,String[] state,Thread TIME){
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateCardSql=null;
            String updateOtherSql=null;
            switch(state[0]){
                case "1":
                case "2":
                    //对card_info表进行更新
                    updateCardSql="update atm.card_info set avail_amount = "+state[2]+" where card_id="+"'"+card+"'";
                    statement.executeUpdate(updateCardSql);
                    //对ATM机余额进行更新
                    updateOtherSql="update atm.atm_info set avail_amount = "+state[1]+" where atm_id="+"'"+atm_info.getAtm_id()+"'";
                    statement.executeUpdate(updateOtherSql);
                    break;
                case "4":
                    //对card_info表进行更新
                    updateCardSql="update atm.card_info set etc_amount = "+state[2]+" where card_id="+"'"+card+"'";
                    statement.executeUpdate(updateCardSql);
                    //对ATM机余额进行更新
                    updateOtherSql="update atm.atm_info set avail_amount = "+state[1]+" where atm_id="+"'"+atm_info.getAtm_id()+"'";
                    statement.executeUpdate(updateOtherSql);
                    break;
                case "-4":
                    //对card_info表进行更新
                    updateCardSql="update atm.card_info set avail_amount = "+state[1]+" where card_id="+"'"+card+"'";
                    statement.executeUpdate(updateCardSql);
                    //对ATM机余额进行更新
                    updateOtherSql="update atm.card_info set etc_amount = "+state[2]+" where card_id="+"'"+card+"'";
                    statement.executeUpdate(updateOtherSql);
                    break;
            }

            Date date=new Date();
            SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat dateFormatid=new SimpleDateFormat("yyyyMMddhhmmss");

            String transaction_id=dateFormatid.format(date);//日期作为编号
            String transaction_date=dateFormat.format(date);
            String atm_id= atm_info.getAtm_id();
            String atm_location=atm_info.getAtm_location();
            String transaction_type=type;
            String source_card_id=card;
            String dest_card_id=card;
            String transaction_amount=state[3];
            String excess_amount=state[2];

            //对transaction_info表进行更新
            String insertSql="insert into atm.transaction_info(transaction_id,transaction_date,atm_id,atm_location,transaction_type,source_card_id,dest_card_id,transaction_amount,excess_amount) values("+"'"+transaction_id+"'"+","+"'"+transaction_date+"'"+","+"'"+atm_id+"'"+","+"'"+atm_location+"'"+","+"'"+transaction_type+"'"+","+"'"+source_card_id+"'"+","+"'"+dest_card_id+"'"+","+"'"+transaction_amount+"'"+","+"'"+excess_amount+"'"+")";
            statement.executeUpdate(insertSql);

            //获取户主名：
            String selectNameSql = "select * from atm.card_info where card_id=" + "'" + card + "'";
            ResultSet rsName = statement.executeQuery(selectNameSql);
            rsName.next();
            String owner_name = rsName.getString("owner_name");
            String newName = owner_name.replace(owner_name.charAt(0), '*');
            rsName.close();
            conn.close();

            String[] receipt={transaction_id,transaction_date,atm_id,atm_location,transaction_type,newName,source_card_id,dest_card_id,transaction_amount,excess_amount};
            dispose();
            success successPage=new success(card,receipt);
            successPage.setVisible(true);
            TIME.stop();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    //执行确认密码后的转账等操作
    private void transfer_actionPerformed(String type,String card,String[] state,Thread TIME){
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            //对card_info表进行更新
            String updateSql="update atm.card_info set avail_amount = "+state[2]+" where card_id="+"'"+card+"'";
            statement.executeUpdate(updateSql);
            //对目标账户进行更新
            String selectObjectCardSql="select * from atm.card_info where card_id="+"'"+state[1]+"'";
            ResultSet rsObjectCard=statement.executeQuery(selectObjectCardSql);
            rsObjectCard.next();
            String ObjectCardavail_amount=rsObjectCard.getString("avail_amount");
            String ObjectCardnew_amount=String.valueOf(Double.valueOf(ObjectCardavail_amount)+(Double.valueOf(state[3])));
            rsObjectCard.close();

            String updateAtmSql="update atm.card_info set avail_amount = "+ObjectCardnew_amount+" where card_id="+"'"+state[1]+"'";
            statement.executeUpdate(updateAtmSql);

            Date date=new Date();
            SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat dateFormatid=new SimpleDateFormat("yyyyMMddhhmmss");

            String transaction_id=dateFormatid.format(date);//日期作为编号
            String transaction_date=dateFormat.format(date);
            String atm_id= atm_info.getAtm_id();
            String atm_location=atm_info.getAtm_location();
            String transaction_type=type;
            String source_card_id=card;
            String dest_card_id=state[1];
            String transaction_amount=state[3];
            String excess_amount=state[2];

            //对transaction_info表进行更新
            String insertSql="insert into atm.transaction_info(transaction_id,transaction_date,atm_id,atm_location,transaction_type,source_card_id,dest_card_id,transaction_amount,excess_amount) values("+"'"+transaction_id+"'"+","+"'"+transaction_date+"'"+","+"'"+atm_id+"'"+","+"'"+atm_location+"'"+","+"'"+transaction_type+"'"+","+"'"+source_card_id+"'"+","+"'"+dest_card_id+"'"+","+"'"+transaction_amount+"'"+","+"'"+excess_amount+"'"+")";
            statement.executeUpdate(insertSql);

            //获取户主名：
            String selectNameSql = "select * from atm.card_info where card_id=" + "'" + card + "'";
            ResultSet rsName = statement.executeQuery(selectNameSql);
            rsName.next();
            String owner_name = rsName.getString("owner_name");
            String newName = owner_name.replace(owner_name.charAt(0), '*');
            rsName.close();
            conn.close();

            String[] receipt={transaction_id,transaction_date,atm_id,atm_location,transaction_type,newName,source_card_id,dest_card_id,transaction_amount,excess_amount};
            dispose();
            success successPage=new success(card,receipt);
            successPage.setVisible(true);
            TIME.stop();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //执行缴费操作
    private void payment_actionPeroformed(String type,String card,String[] state,Thread TIME){
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            //对card_info表进行更新
            String updateSql="update atm.card_info set etc_amount = "+state[2]+" where card_id="+"'"+card+"'";
            statement.executeUpdate(updateSql);
            //对违章记录进行删除
            String selectCardSql="select * from atm.card_info where card_id="+"'"+card+"'";
            ResultSet rsCard=statement.executeQuery(selectCardSql);
            rsCard.next();
            String Cardowner_id=rsCard.getString("owner_id");
            rsCard.close();

            System.out.println("violation_id="+state[1]);
            String[] violation_id=state[1].split(" ");
            System.out.println("长度="+violation_id.length);
            for (int i = 0; i < violation_id.length; i++) {
                System.out.println(violation_id[i]);
                String updateAtmSql="delete from atm.vehicle_violation_info where owner_id="+"'"+Cardowner_id+"'"+" and violation_id="+"'"+violation_id[i]+"'";
                statement.executeUpdate(updateAtmSql);
            }

            Date date=new Date();
            SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat dateFormatid=new SimpleDateFormat("yyyyMMddhhmmss");

            String transaction_id=dateFormatid.format(date);//日期作为编号
            String transaction_date=dateFormat.format(date);
            String atm_id= atm_info.getAtm_id();
            String atm_location=atm_info.getAtm_location();
            String transaction_type=type;
            String source_card_id=card;
            String dest_card_id=card;
            String transaction_amount=state[3];
            String excess_amount=state[2];

            //对transaction_info表进行更新
            String insertSql="insert into atm.transaction_info(transaction_id,transaction_date,atm_id,atm_location,transaction_type,source_card_id,dest_card_id,transaction_amount,excess_amount) values("+"'"+transaction_id+"'"+","+"'"+transaction_date+"'"+","+"'"+atm_id+"'"+","+"'"+atm_location+"'"+","+"'"+transaction_type+"'"+","+"'"+source_card_id+"'"+","+"'"+dest_card_id+"'"+","+"'"+transaction_amount+"'"+","+"'"+excess_amount+"'"+")";
            statement.executeUpdate(insertSql);

            //获取户主名：
            String selectNameSql = "select * from atm.card_info where card_id=" + "'" + card + "'";
            ResultSet rsName = statement.executeQuery(selectNameSql);
            rsName.next();
            String owner_name = rsName.getString("owner_name");
            String newName = owner_name.replace(owner_name.charAt(0), '*');
            rsName.close();
            conn.close();

            String[] receipt={transaction_id,transaction_date,atm_id,atm_location,transaction_type,newName,source_card_id,dest_card_id,transaction_amount,excess_amount};
            dispose();
            success successPage=new success(card,receipt);
            successPage.setVisible(true);
            TIME.stop();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //确认
    private void confirm_buttonActionPerformed(ActionEvent e,String card,String[] state,Thread TIME) {
        String password=password_input.getText();
        //连接数据库验证，成功就跳转
        if(password.length()!=6){
            JOptionPane.showMessageDialog(this,"请输入正确长度的银行卡密码...","Warning",JOptionPane.WARNING_MESSAGE);
        }else{
            connection c=new connection();
            Connection conn=c.CreateSqlConnection();
            String selectSql="select * from atm.card_info where card_id="+card;
            try {
                Statement statement=conn.createStatement();
                ResultSet rs=statement.executeQuery(selectSql);
                //如果存在，则跳转到index页面
                rs.next();
                boolean card_state=rs.getBoolean("card_state");//0为正常，1为冻结
                System.out.println(card_state);
                String rightPassword=rs.getString("card_password");
                rs.close();
                if(card_state==false){//正常
                    if(rightPassword.equals(password)){
                        switch(state[0]){
                            case "0":
                                dispose();
                                index indexPage=new index(card);
                                indexPage.setVisible(true);
                                TIME.stop();
                                break;
                            case "1":
                                //存款
                                actionPerformed("deposit",card,state,TIME);
                                break;
                            case "2":
                                //取款
                                actionPerformed("withdrawal",card,state,TIME);
                                break;
                            case "3":
                                //转账
                                transfer_actionPerformed("transfer",card,state,TIME);
                                break;
                            case "4":
                                //充值-现金充值
                                actionPerformed("charge",card,state,TIME);
                                break;
                            case "-4":
                                //充值-划款
                                actionPerformed("charge",card,state,TIME);
                                break;
                            case "5":
                                //缴费
                                payment_actionPeroformed("payment",card,state,TIME);
                                break;
                        }
                    }else{
                        //如果不存在，则弹出信息框
                        wrong_Time-=1;
                        if(wrong_Time>0){
                            JOptionPane.showMessageDialog(this,"密码错误,请重新输入,剩余"+wrong_Time+"次机会","ERROR",JOptionPane.ERROR_MESSAGE);
                        } else {
                            //冻结操作
                            String updateSql="update atm.card_info set card_state="+1+" where card_id="+card;
                            statement.executeUpdate(updateSql);
                            JOptionPane.showMessageDialog(this,"密码输入错误3次,卡已被冻结，请到柜台解冻...","ERROR",JOptionPane.ERROR_MESSAGE);
                            dispose();
                            input_card cardPage=new input_card();
                            cardPage.setVisible(true);
                            TIME.stop();
                        }
                    }
                }else{
                    JOptionPane.showMessageDialog(this,"卡已被冻结，请先到柜台解冻...","ERROR",JOptionPane.ERROR_MESSAGE);
                }
                conn.close();
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }
    }
    //更正
    private void reset_buttonActionPerformed(ActionEvent e) {
        password_input.setText(null);
    }
    //返回上一页
    private void back_buttonActionPerformed(ActionEvent e,String card,String[] state,Thread TIME) {
       if(state[0]=="0") {
           JOptionPane.showMessageDialog(null, "操作超时，请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
           //返回银行卡插入页面
           dispose();
           input_card cardPage = new input_card();
           cardPage.setVisible(true);
           TIME.stop();
       }else{
           //返回index界面
           dispose();
           index indexPage=new index(card);
           indexPage.setVisible(true);
           TIME.stop();
        }
    }
    //退卡
    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();

    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        nav = new JPanel();
        timer = new JTextField();
        date = new JTextField();
        signal = new JTextField();
        password_label = new JLabel();
        password_input = new JPasswordField();
        reset_button = new JButton();
        back_button = new JButton();
        confirm_button = new JButton();
        return_button = new JButton();

        //======== this ========
        setTitle("ATM");
        setResizable(false);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        var contentPane = getContentPane();

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- timer ----
            timer.setText("60");
            timer.setEditable(false);
            timer.setBackground(new Color(187, 187, 187));
            timer.setFont(timer.getFont().deriveFont(timer.getFont().getSize() + 1f));

            //---- date ----
            date.setText("2019.11.17 11:11:11");
            date.setEditable(false);
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(GroupLayout.Alignment.TRAILING, navLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
            );
        }

        //---- password_label ----
        password_label.setText(" \u8bf7\u8f93\u5165\u94f6\u884c\u5361\u5bc6\u7801...");
        password_label.setFont(password_label.getFont().deriveFont(password_label.getFont().getSize() + 1f));

        //---- reset_button ----
        reset_button.setText("\u66f4\u6b63");
        reset_button.addActionListener(e -> reset_buttonActionPerformed(e));

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(reset_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(confirm_button))
                .addComponent(nav, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addContainerGap(140, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(password_input, GroupLayout.PREFERRED_SIZE, 160, GroupLayout.PREFERRED_SIZE)
                        .addComponent(password_label, GroupLayout.PREFERRED_SIZE, 136, GroupLayout.PREFERRED_SIZE))
                    .addGap(178, 178, 178))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(86, 86, 86)
                    .addComponent(password_label, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(password_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(reset_button)
                        .addComponent(confirm_button))
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(back_button)
                        .addComponent(return_button))
                    .addGap(15, 15, 15))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel nav;
    private JTextField timer;
    private JTextField date;
    private JTextField signal;
    private JLabel password_label;
    private JPasswordField password_input;
    private JButton reset_button;
    private JButton back_button;
    private JButton confirm_button;
    private JButton return_button;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
