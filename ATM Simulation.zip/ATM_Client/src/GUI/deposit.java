/*
 * Created by JFormDesigner on Wed Nov 20 15:13:37 CST 2019
 */

package GUI;

import sql.atm_info;
import sql.connection;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 * @author liujingxiang
 */
public class deposit extends JFrame {
    long finalTime=60;

    public deposit(String card,String type) {
        initComponents();
        Thread TIME=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        Thread.sleep(1000);
                        finalTime-=1;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        TIME.start();

        Thread DATE=new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    Date time=new Date();
                    SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    date.setText(dateFormat.format(time));
                    if(finalTime==0){
                        ActionEvent e=null;
                        back_buttonActionPerformed(e,card,TIME);
                        break;
                    }else{
                        timer.setText(String.valueOf(finalTime));
                    }
                }
            }
        });
        DATE.start();

        //只能输入数字，且限定长度
        amount_input.addKeyListener(new KeyAdapter() {
                @Override
                public void keyTyped(KeyEvent e) {
                int key=e.getKeyChar();
                if(amount_input.getText().length()<5){
                    if((key<KeyEvent.VK_0 || key>KeyEvent.VK_9) && key!=KeyEvent.VK_BACK_SPACE){
                        e.consume();
                    }
                }else{
                    e.consume();
                } }
            });
        confirm_button.addActionListener(e->confirm_buttonActionPerformed(e,card,type,TIME));
        back_button.addActionListener(e->back_buttonActionPerformed(e,card,TIME));
        return_button.addActionListener(e->return_buttonActionPerformed(e,TIME));
    }



    private void back_buttonActionPerformed(ActionEvent e,String card,Thread TIME) {
        dispose();
        index indexPage=new index(card);
        indexPage.setVisible(true);
        TIME.stop();
    }

    private void confirm_buttonActionPerformed(ActionEvent e,String card,String type,Thread TIME) {
        String deposit_amount=amount_input.getText();
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        String selectCardSql="select * from atm.card_info where card_id="+"'"+card+"'";
        String selectAtmSql="select * from atm.atm_info where atm_id="+"'"+ atm_info.getAtm_id()+"'";
        if(type.equals("1")){
            try {
                Statement statement=conn.createStatement();
                ResultSet rsCard=statement.executeQuery(selectCardSql);
                rsCard.next();

                String Cardavail_amount=rsCard.getString("avail_amount");
                String Cardnew_amount=String.valueOf(Double.valueOf(Cardavail_amount)+(Double.valueOf(deposit_amount)));

                ResultSet rsAtm=statement.executeQuery(selectAtmSql);
                rsAtm.next();
                String Atmavail_amount=rsAtm.getString("avail_amount");
                String Atmnew_amount=String.valueOf(Double.valueOf(Atmavail_amount)+(Double.valueOf(deposit_amount)));
                rsCard.close();
                conn.close();
                System.out.println("atm="+Atmnew_amount+",card="+Cardnew_amount);
                dispose();
                String[] state=new String[]{type,Atmnew_amount,Cardnew_amount,deposit_amount};//类型、Atm机余额，Card剩余金额，交易金额
                input_password passwordPage=new input_password(card,state);
                passwordPage.setVisible(true);
                TIME.stop();
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }else if(type.equals("4")){//现金存
            try {
                Statement statement=conn.createStatement();
                ResultSet rsCard=statement.executeQuery(selectCardSql);
                rsCard.next();

                String Cardetc_amount=rsCard.getString("etc_amount");
                String Cardnew_amount=String.valueOf(Double.valueOf(Cardetc_amount)+(Double.valueOf(deposit_amount)));

                ResultSet rsAtm=statement.executeQuery(selectAtmSql);
                rsAtm.next();
                String Atmavail_amount=rsAtm.getString("avail_amount");
                String Atmnew_amount=String.valueOf(Double.valueOf(Atmavail_amount)+(Double.valueOf(deposit_amount)));
                rsCard.close();
                conn.close();
                System.out.println("atm="+Atmnew_amount+",card="+Cardnew_amount);
                dispose();
                String[] state=new String[]{type,Atmnew_amount,Cardnew_amount,deposit_amount};//类型、Atm机余额，CardETC剩余金额，交易金额
                input_password passwordPage=new input_password(card,state);
                passwordPage.setVisible(true);
                TIME.stop();
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }else if(type.equals("-4")){//划款
            try {
                System.out.println("准备划款...");
                Statement statement=conn.createStatement();
                ResultSet rsCard=statement.executeQuery(selectCardSql);
                rsCard.next();

                String Cardavail_amount=rsCard.getString("avail_amount");
                if(Double.valueOf(Cardavail_amount)<Double.valueOf(deposit_amount)){
                    JOptionPane.showMessageDialog(this,"账户余额不足...","ERROR",JOptionPane.ERROR_MESSAGE);
                }else{
                    String Cardnew_amount=String.valueOf(Double.valueOf(Cardavail_amount)-(Double.valueOf(deposit_amount)));
                    System.out.println("准备划款1...");

                    String Cardetc_amount=rsCard.getString("etc_amount");
                    String Cardetcnew_amount=String.valueOf(Double.valueOf(Cardetc_amount)+(Double.valueOf(deposit_amount)));
                    rsCard.close();
                    conn.close();
                    System.out.println("准备划款2...");

                    dispose();
                    String[] state=new String[]{type,Cardnew_amount,Cardetcnew_amount,deposit_amount};//类型、Card剩余金额，CardETC剩余余额，交易金额
                    input_password passwordPage=new input_password(card,state);
                    passwordPage.setVisible(true);
                    TIME.stop();
                }
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }


    }

    private void return_buttonActionPerformed(ActionEvent e,Thread TIME) {
        JOptionPane.showMessageDialog(null, "请取回银行卡...", "Warning", JOptionPane.WARNING_MESSAGE);
        //对atm_info表中state_flag字段更新
        connection c=new connection();
        Connection conn=c.CreateSqlConnection();
        Statement statement= null;
        try {
            statement = conn.createStatement();
            String updateSql="update atm.atm_info set state_flag = "+false+" where atm_id ="+"'"+ atm_info.getAtm_id()+"'";
            statement.executeUpdate(updateSql);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        //返回银行卡插入页面
        dispose();
        input_card cardPage=new input_card();
        cardPage.setVisible(true);
        TIME.stop();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        back_button = new JButton();
        return_button = new JButton();
        confirm_button = new JButton();
        amount_label = new JLabel();
        amount_input = new JTextField();
        nav = new JPanel();
        signal = new JTextField();
        timer = new JTextField();
        date = new JTextField();

        //======== this ========
        setResizable(false);
        setTitle("ATM");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.white);
        setIconImage(new ImageIcon(getClass().getResource("/icon.png")).getImage());
        setFont(new Font(Font.DIALOG, Font.PLAIN, 13));
        var contentPane = getContentPane();

        //---- back_button ----
        back_button.setText("\u8fd4\u56de");

        //---- return_button ----
        return_button.setText("\u9000\u5361");

        //---- confirm_button ----
        confirm_button.setText("\u786e\u8ba4");

        //---- amount_label ----
        amount_label.setText("\u8bf7\u8f93\u5165\u91d1\u989d...");
        amount_label.setFont(amount_label.getFont().deriveFont(amount_label.getFont().getSize() + 1f));

        //======== nav ========
        {
            nav.setBackground(new Color(187, 187, 187));

            //---- signal ----
            signal.setText("\u4e2d\u56fd\u5efa\u8bbe\u94f6\u884c");
            signal.setEditable(false);
            signal.setBackground(new Color(187, 187, 187));
            signal.setFont(signal.getFont().deriveFont(signal.getFont().getStyle() | Font.BOLD, signal.getFont().getSize() + 3f));

            //---- timer ----
            timer.setText("60");
            timer.setBackground(new Color(187, 187, 187));
            timer.setFont(timer.getFont().deriveFont(timer.getFont().getSize() + 1f));

            //---- date ----
            date.setText("2019.1.17 11:11:11");
            date.setBackground(new Color(187, 187, 187));
            date.setFont(date.getFont().deriveFont(date.getFont().getSize() + 1f));

            GroupLayout navLayout = new GroupLayout(nav);
            nav.setLayout(navLayout);
            navLayout.setHorizontalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addComponent(signal, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                        .addComponent(timer, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75)
                        .addComponent(date, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE))
            );
            navLayout.setVerticalGroup(
                navLayout.createParallelGroup()
                    .addGroup(navLayout.createSequentialGroup()
                        .addGroup(navLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(date, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(timer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                            .addComponent(signal, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))
            );
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(back_button)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                    .addComponent(return_button))
                .addGroup(GroupLayout.Alignment.TRAILING, contentPaneLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(confirm_button))
                .addComponent(nav, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addGroup(contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGap(147, 147, 147)
                            .addComponent(amount_input, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE))
                        .addGroup(contentPaneLayout.createSequentialGroup()
                            .addGap(176, 176, 176)
                            .addComponent(amount_label, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(181, Short.MAX_VALUE))
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addGroup(contentPaneLayout.createSequentialGroup()
                    .addComponent(nav, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                    .addComponent(amount_label, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(amount_input, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(42, 42, 42)
                    .addComponent(confirm_button)
                    .addGap(18, 18, 18)
                    .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        .addComponent(return_button)
                        .addComponent(back_button))
                    .addGap(19, 19, 19))
        );
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JButton back_button;
    private JButton return_button;
    private JButton confirm_button;
    private JLabel amount_label;
    private JTextField amount_input;
    private JPanel nav;
    private JTextField signal;
    private JTextField timer;
    private JTextField date;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
