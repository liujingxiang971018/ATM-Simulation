package sql;

import java.io.*;

public class atm_info {

    public static void setAtm(String atm_id, String atm_location) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("init.txt"));
            bw.write("atm_id=" + atm_id + "\n");
            bw.write("atm_location=" + atm_location + "\n");
            bw.flush();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getAtm_id() {
        String atm_id = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader("init.txt"));
            String atm = br.readLine();
            while(atm!=null){
                if(atm.contains("atm_id=")){
                    int start_index = atm.indexOf("atm_id=");
                    atm_id = atm.substring(start_index + 7);
                    System.out.println("atm_id="+atm_id);
                    break;
                }else{
                    atm=br.readLine();
                }
            }
            br.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return atm_id;
    }

    public static String getAtm_location() {
        String atm_location = null;
        try {
            BufferedReader br = new BufferedReader(new FileReader("init.txt"));
            String atm = br.readLine();
            while(atm!=null){
                if(atm.contains("atm_location=")){
                    int start_index = atm.indexOf("atm_location=");
                    atm_location = atm.substring(start_index + 13);
                    System.out.println("atm_location="+atm_location);
                    break;
                }else{
                    atm=br.readLine();
                }
            }
            br.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return atm_location;
    }
}