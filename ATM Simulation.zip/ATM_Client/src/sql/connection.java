package sql;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connection {
    private static ComboPooledDataSource dataSource;

    static {
        try {
            //获取c3p0连接池对象
            dataSource = new ComboPooledDataSource();
            dataSource.setUser("root");
            dataSource.setPassword("969789");
            dataSource.setJdbcUrl("jdbc:mysql://123.57.227.78:3306/atm?serverTimezone=UTC&useSSL=false");
            dataSource.setDriverClass("com.mysql.jdbc.Driver");
            dataSource.setInitialPoolSize(2);//初始化池大小
            dataSource.setMaxIdleTime(30);//最大空闲时间
            dataSource.setMaxPoolSize(10);//最多连接数
            dataSource.setMinPoolSize(2);//最少连接数
            dataSource.setMaxStatements(50);//每次最多可以执行多少个批处理语句
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Connection CreateSqlConnection(){

        Connection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
